package com.example.quiz.controller;

import com.example.quiz.model.User;
import com.example.quiz.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

@Controller
public class AuthController {

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private PasswordEncoder passwordEncoder;

    @GetMapping("/register")
    public String showRegister() {
        return "register";
    }

    @PostMapping("/register")
    public String register(@ModelAttribute User user) {
        user.setRole("ROLE_USER");
        // Bracket error fix: passwordEncoder.encode(user.getPassword())
        user.setPassword(passwordEncoder.encode(user.getPassword())); 
        userRepository.save(user);
        return "redirect:/login";
    }
}