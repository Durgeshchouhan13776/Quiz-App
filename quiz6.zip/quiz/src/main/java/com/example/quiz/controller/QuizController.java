package com.example.quiz.controller;

import com.example.quiz.model.Question;
import com.example.quiz.repository.QuestionRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@Controller
public class QuizController {

    @Autowired
    private QuestionRepository repo;

    @GetMapping("/quiz/{topic}")
    public String startQuiz(@PathVariable String topic, Model model) {
        List<Question> questions = repo.findByCategory(topic);
        model.addAttribute("questions", questions);
        model.addAttribute("topic", topic.toUpperCase());
        return "quiz-page"; // Ye templates/quiz-page.html ko kholega
    }
}