package com.example.quiz.repository;

import com.example.quiz.model.Question;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface QuestionRepository extends JpaRepository<Question, Long> {
    // Ye line add karna zaroori hai topic-wise quiz ke liye
    List<Question> findByCategory(String category);
}