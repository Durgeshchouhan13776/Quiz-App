package com.example.quiz.controller;


import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import com.example.quiz.model.Question;
import com.example.quiz.repository.QuestionRepository;


@RestController
@RequestMapping("/api/quiz")
@CrossOrigin
public class QuizController {


@Autowired
private QuestionRepository repo;


@GetMapping("/questions")
public List<Question> getAllQuestions() {
return repo.findAll();
}
}