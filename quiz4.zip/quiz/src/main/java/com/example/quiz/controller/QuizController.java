@Controller
public class QuizController {
    @Autowired
    private QuestionRepository repo;

    @GetMapping("/quiz/{topic}")
    public String startQuiz(@PathVariable String topic, Model model) {
        List<Question> questions = repo.findByCategory(topic);
        model.addAttribute("questions", questions);
        model.addAttribute("topic", topic);
        return "quiz-page"; // Is naam ki HTML file templates mein banayein
    }
}