let questions = [];


fetch('http://localhost:8080/api/quiz/questions')
.then(res => res.json())
.then(data => {
questions = data;
loadQuiz();
});


function loadQuiz() {
let quizDiv = document.getElementById('quiz');
quizDiv.innerHTML = '';


questions.forEach((q, index) => {
quizDiv.innerHTML += `
<div class="question">
<p>${index + 1}. ${q.question}</p>
<input type="radio" name="q${index}" value="A"> ${q.optionA}<br>
<input type="radio" name="q${index}" value="B"> ${q.optionB}<br>
<input type="radio" name="q${index}" value="C"> ${q.optionC}<br>
<input type="radio" name="q${index}" value="D"> ${q.optionD}<br>
</div>
`;
});
}


function submitQuiz() {
let score = 0;


questions.forEach((q, index) => {
let selected = document.querySelector(`input[name="q${index}"]:checked`);
if (selected && selected.value === q.correctAnswer) {
score++;
}
});


alert(`Your Score: ${score}/${questions.length}`);
}